# Redline Scientific Calculator

## Run locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
5. Wait for GitHub Pages to publish the site.

Features: standard/scientific modes, trig functions, DEG/RAD toggle, calculation history, four colour themes, optional button sounds, keyboard input, responsive layout.
